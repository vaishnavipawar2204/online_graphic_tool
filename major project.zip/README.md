# Matty — Online Graphic Design Tool (Starter)

This zip contains a **starter** full-stack project named Matty:
- `backend/` — Express + MongoDB + JWT starter API (basic auth + project endpoints).
- `frontend/` — Vite + React sample with a `react-konva` canvas editor (demo).

This is a development starter. It is intentionally minimal so you can run and extend it.

## Quick local run (development)

### Backend
1. cd backend
2. cp .env.example .env and fill values (or run a local MongoDB, default falls back to mongodb://127.0.0.1:27017/matty-dev)
3. npm install
4. npm run dev
- Server will run on port 4000 by default.

### Frontend
1. cd frontend
2. npm install
3. npm run dev
- Frontend will run on http://localhost:3000 (Vite default).

## Deploy
- Backend: push to GitHub and deploy to Render (or any Node host). Set env vars from backend/.env.example.
- Frontend: push to GitHub and deploy to Vercel. Set VITE_API_URL to your backend URL.

## What you can do next
- Hook frontend auth to backend auth endpoints.
- Implement Cloudinary signed uploads.
- Add user sessions/cookies, project list, templates, and deeper canvas features.

Enjoy — ask me to expand or to create a GitHub-ready repo (I can also provide GitHub actions or a Dockerfile).
