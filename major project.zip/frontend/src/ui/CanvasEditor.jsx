import React, { useRef, useState } from 'react';
import { Stage, Layer, Text, Image as KImage } from 'react-konva';
import useImage from 'use-image';

function URLImage({ src, x=50, y=50 }) {
  const [img] = useImage(src);
  return <KImage image={img} x={x} y={y} draggable />;
}

export default function CanvasEditor({ initialScene, onSave }) {
  const stageRef = useRef();
  const [elements, setElements] = useState([
    { type: 'text', x: 50, y: 20, text: 'Hello Matty', id: 1 }
  ]);
  const addText = () => {
    setElements(prev => [...prev, { type: 'text', x: 60, y: 80, text: 'New Text', id: Date.now() }]);
  };
  const addSampleImage = () => {
    setElements(prev => [...prev, { type: 'image', src: 'https://picsum.photos/300/200', x: 120, y: 100, id: Date.now() }]);
  };
  const exportPNG = () => {
    const uri = stageRef.current.toDataURL({ pixelRatio: 2 });
    const link = document.createElement('a');
    link.download = 'matty-export.png';
    link.href = uri;
    link.click();
  };
  const saveProject = () => {
    const json = stageRef.current.toJSON();
    if(onSave) onSave({ sceneJSON: JSON.parse(json) });
  };

  return (
    <div>
      <div style={{ marginBottom: 8 }}>
        <button onClick={addText}>Add text</button>{' '}
        <button onClick={addSampleImage}>Add image</button>{' '}
        <button onClick={exportPNG}>Export PNG</button>{' '}
        <button onClick={saveProject}>Save</button>
      </div>
      <div style={{ border: '1px solid #ddd', width: 1000, height: 600 }}>
        <Stage width={1000} height={600} ref={stageRef}>
          <Layer>
            {elements.map(el => {
              if(el.type === 'text') return <Text key={el.id} x={el.x} y={el.y} text={el.text} draggable/>;
              if(el.type === 'image') return <URLImage key={el.id} src={el.src} x={el.x} y={el.y} />;
              return null;
            })}
          </Layer>
        </Stage>
      </div>
    </div>
  );
}
