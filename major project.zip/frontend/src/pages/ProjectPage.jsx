import React, { useRef, useState } from 'react';
import CanvasEditor from '../ui/CanvasEditor';

export default function ProjectPage({ isNew }) {
  const [saved, setSaved] = useState(false);

  const handleSave = async (payload) => {
    // This demo doesn't connect to backend automatically.
    // When backend URL is set in REACT_APP_API_URL and auth implemented,
    // you can POST to /api/projects with the JWT in Authorization header.
    console.log('SAVE payload', payload);
    setSaved(true);
    setTimeout(()=> setSaved(false), 2000);
  };

  return (
    <div style={{ padding: 12 }}>
      <h2>{isNew ? 'New Project' : 'Project Editor'}</h2>
      <div style={{ display: 'flex', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <CanvasEditor onSave={handleSave} />
          {saved && <div style={{ marginTop: 8, color: 'green' }}>Saved (demo)</div>}
        </div>
        <aside style={{ width: 260, borderLeft: '1px solid #eee', paddingLeft: 12 }}>
          <h3>Inspector</h3>
          <p>Assets, layers & properties will appear here.</p>
        </aside>
      </div>
    </div>
  );
}
