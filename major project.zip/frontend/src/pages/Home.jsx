import React from 'react';

export default function Home(){
  return (
    <div style={{ padding: 20 }}>
      <h1>Matty — Online Graphic Design Tool (Demo)</h1>
      <p>This is a starter demo. Click <a href='/project/new'>New Project</a> to open the editor.</p>
    </div>
  );
}
