require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/matty-dev';
mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('MongoDB connected'))
  .catch(err => console.error('Mongo connect err', err));

app.get('/', (req,res)=> res.send({ ok:true, message: 'Matty API running' }));

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`Server listening ${PORT}`));
