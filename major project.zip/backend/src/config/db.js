// optional helper - currently server.js connects directly
module.exports = {};
