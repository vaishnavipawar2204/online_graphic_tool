const express = require('express');
const auth = require('../middleware/auth');
const Project = require('../models/Project');

const router = express.Router();

router.post('/', auth, async (req,res)=>{
  const { title, sceneJSON, assets } = req.body;
  const project = await Project.create({ owner: req.user.id, title, sceneJSON, assets });
  res.json(project);
});

router.get('/', auth, async (req,res)=>{
  const projects = await Project.find({ owner: req.user.id }).sort({ updatedAt: -1 });
  res.json(projects);
});

router.get('/:id', auth, async (req,res)=>{
  const p = await Project.findById(req.params.id);
  if(!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

router.put('/:id', auth, async (req,res)=>{
  const updates = req.body;
  const p = await Project.findOneAndUpdate({ _id: req.params.id, owner: req.user.id }, updates, { new: true });
  if(!p) return res.status(404).json({ message: 'Not found or not allowed' });
  res.json(p);
});

router.delete('/:id', auth, async (req,res)=>{
  const p = await Project.findOneAndDelete({ _id: req.params.id, owner: req.user.id });
  if(!p) return res.status(404).json({ message: 'Not found or not allowed' });
  res.json({ message: 'Deleted' });
});

module.exports = router;
